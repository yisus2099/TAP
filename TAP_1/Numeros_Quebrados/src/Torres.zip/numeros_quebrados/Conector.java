package numeros_quebrados;


public class Conector {
/*
    public int static  numeros_quebrados.Quebrado quebrado = new numeros_quebrados.Quebrado();
    public static numeros_quebrados.OpQuebrados Opqueb = new numeros_quebrados.OpQuebrados();
*/
}
